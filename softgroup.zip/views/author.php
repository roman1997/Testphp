<div class="col-xs-12 col-sm-6 col-md-8 col-lg-8">
<div class="row">
   
    <div class="text-left">
        
        <h3>Роман Понюк</h3>
        <h3>10.08.1997</h3>
        <h3>Знаю: html5,css3,js,php(основи),С(Основи)</h3>
    </div>
</div>

</div>