<?php
if (isset($_POST['submit'])) {
    function perfect_number($x){
        $n=$_POST['perfect_number'];  
            $p = 0;
            for($j = 6; $j <= $n; $j++)
            {
                $x = $j;
                for($i = 1; $i < $x; $i++)
                {
                    if($x % $i == 0)
                    $p+=$i;
                }
                if($p == $j)
                    echo "Число ".$j." досконале <br>";
                $p = 0; 
            }
        } 
    $t = 1;
    perfect_number($t);
}
?>
    <div class="col-xs-12 col-sm-6 col-md-8 col-lg-8">
         <strong>Завдання 1</strong>
    <p>
        У форму вводиться число N. Знайти всі досконалі числа до N. Досконале число - це таке число, що дорівнює сумі всіх своїх дільників, крім себе самого. Наприклад, число 6 є досконалим, тому що крім себе самого ділиться на числа 1, 2 і 3, які в сумі дають 6.
    </p>
        <form action="" method="post">
            <div class="form-group">
                <div class="input-group">
                    <input class="form-control" type="text" placeholder="Введіть число" name="perfect_number">
                    <button class="btn" name="submit">Знайти досконалі числа</button>
                </div>
            </div>
        </form>
    <div class="code">
        <h2>Код розвязку</h2>
        <pre class="php">	
       if (isset($_POST['submit'])) {
            function perfect_number($x){
                $n=$_POST['perfect_number'];  
                    $p = 0;
                    for($j = 6; $j <= $n; $j++)
                    {
                        $x = $j;
                        for($i = 1; $i < $x; $i++)
                        {
                            if($x % $i == 0)
                            $p+=$i;
                        }
                        if($p == $j)
                            echo "Число ".$j." досконале <br>";
                        $p = 0; 
                    }
                } 
            $t = 1;
            perfect_number($t);
        }
        </pre>
        
    </div>
    </div>