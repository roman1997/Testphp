<?php
    function prost($n){
     if ($n<2)
        return false;
     for($i=2; $i<= sqrt($n); $i++){
        if ($n % $i==0){
            return false;
        }   
     }
     return true;
    }
if(isset($_POST['submit'])){  
    $numbers = preg_split('/\s+/', $_POST['prime_n']);
     $counter=0;
        foreach($numbers as $number){
                if (prost($number)) {
                    $counter++;
                        }
                }
        echo $counter; 
    }
?>
    <div class="col-xs-12 col-sm-6 col-md-8 col-lg-8">
        <strong>Завдання 3</strong>
        <p>Вводяться N натуральних чисел більше 2. Підрахувати, скільки серед них простих чисел.</p>
<strong>Розв'язок</strong>
        <form action="" method="post">
            <div class="form-group">
                <div class="input-group">
                    <input class="form-control" type="text" placeholder="Введіть число" name="prime_n" required>
                    <button class="btn" name="submit">Знайти прості числа</button>
             </div>                
                <div class="">
                   <h2>Код розв'язку</h2>
                    <code>
                <pre>
 function prost($n){
     if ($n<2)
        return false;
     for($i=2; $i<= sqrt($n); $i++){
        if ($n % $i==0){
            return false;
        }   
     }
     return true;
    }
if(isset($_POST['submit'])){  
    $numbers = preg_split('/\s+/', $_POST['prime_n']);
     $counter=0;
        foreach($numbers as $number){
                if (prost($number)) {
                    $counter++;
                        }
                }
        echo $counter; 
    }
                </pre>        
                   
                    </code>
                </div>
            </div>
        </form>
    </div>