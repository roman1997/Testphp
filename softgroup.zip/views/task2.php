<?php
$input_text='';
$max['word']=null;
if (isset($_POST['submit'])) {
    $input_text = $_POST['input_text'];  
    $array = preg_split('/[\s,\.\+;!:?-]+/',$input_text);
    $max['length'] = 0;  
    $max['word'] = '';  
        for($i=0;$i < count($array);$i++)  
        {  
            if(strlen($array[$i]) > $max['length'])  
            {  
            $max['word'] = $array[$i];//найд слово  
            $max['length'] = strlen($array[$i]);  
            }  
        
        }
    $input_text=str_replace($max['word'],'',$input_text);
   // echo 'Найдовше слово: <b>'.$max['word'].'['.$max['length'].']</b>';

}
?>
    <div class="col-xs-12 col-sm-6 col-md-8 col-lg-8">
        <strong>Завдання 2</strong>
        <p>
            У форму вводиться текст, слова в якому розділені пробілами і розділовими знаками. Вилучити з цього тексту всі слова найбільшої довжини. (Слів найбільшої довжини може бути декілька).
        </p>
        <form action="" method="post">
            <h2>Вхідний текст </h2>
            <p>
                Текст (від лат. textus — тканина, з'єднання) — загалом зв'язана і повністю послідовна сукупність знаків. Наука, що вивчає тексти називається герменевтикою.
            </p>
            <h2>Вихідний текст </h2>
            <p id="delete" style="font-weight:800;">
                <?=$input_text?>
            </p>
            <?="<h3>Видалене слово:</h3>".$max["word"]?>
                <div class="form-group">
                    <div class="input-group">
                        <label for="input_text">
                            Введіть текст
                        </label>
                        <textarea rows="3" cols="90" class="form-control" name="input_text" type="text">

                        </textarea>
                        <br>
                        <button class="btn" name="submit">Видалити найдовше слово</button>
                        <h3>
                  
                        </h3>
                    </div>
                </div>
        </form>
                   <h2>Код розв'язку</h2>
                   <h4>php</h4>
                    <code>
                    <pre>
    $input_text = $_POST['input_text'];  
    $array = preg_split('/[\s,\.\+;!:?-]+/',$input_text);
    $max['length'] = 0;  
    $max['word'] = '';  
        for($i=0;$i < count($array);$i++)  
        {  
            if(strlen($array[$i]) > $max['length'])  
            {  
            $max['word'] = $array[$i];//найд слово  
            $max['length'] = strlen($array[$i]);  
            }  
        
        }
    $input_text=str_replace($max['word'],'',$input_text);
                    </pre>
                    </code>
    </div>