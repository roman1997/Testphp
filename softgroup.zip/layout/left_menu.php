<div class="col-xs-12 col-sm-6 col-md-4 col-lg-4">
    <ul class="nav nav-left">
        <li><a href="?action=task1">Завдання 1</a></li>
        <li><a href="?action=task2">Завдання 2</a></li>
        <li><a href="?action=task3">Завдання 3</a></li>
        <li><a href="?action=task4">Завдання 4</a></li>
        <li><a href="?action=task5">Завдання 5</a></li>
        <li><a href="?action=task6">Завдання 6</a></li>
    </ul>
</div>