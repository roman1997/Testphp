</div>
<!--end row-->
</div>
<!--end container-->
<hr>
<footer>
    <div class="container-fluid">
            <h4 class="text-center">Автор: Понюк Роман ©</h4>
            <h4 class="text-center">2016</h4>
    </div>
</footer>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/3.3.5/js/bootstrap.min.js"></script>
</body>

</html>