<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" media="screen" href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/3.3.5/css/bootstrap.min.css">
    <link rel="stylesheet" href="./css/style.css">
    <title>SoftGroup</title>
    <!--  -->

</head>

<body>

    <!--
    <div class="container">
        <div class="row">
            <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12"></div>
        </div>
    </div>
-->
    <div class="container">
        <div class="row">
            <div class="col-xs-12 col-sm-6 col-md-4 col-lg-4">
                <div class="logo">
                    <a href="?action=main"><img class="img-responsive" src="./img/logo.png" alt="logo"></a>
                </div>
            </div>
            <div class="col-xs-12 col-sm-6 col-md-8 col-lg-8">
                <div class="row">
                    <div class="col-xs-12 col-sm-offset-6 col-sm-6 col-md-offset-6 col-md-6 col-lg-offset-6 col-lg-6">
                        <nav class="top-nav">
                            <ul class="nav nav-pills">
                                <li><a href="?action=main">Головна</a></li>
                                <li><a href="?action=author">Автор</a></li>
                                <li><a href="http://www.softgroup.ua" target="_blank">Soft Group</a></li>
                            </ul>
                        </nav>
                    </div>
                </div>
                <div class="row">
                    <div class="col-xs-12  col-sm-9  col-md-9  col-lg-9">
                        <h1 class="text-center">SoftGroup</h1>
                        <h2 class="text-center">Тестове завдання</h2>
                    </div>
                </div>
            </div>




        </div>

        <div class="row">